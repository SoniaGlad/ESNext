console.clear();

// Lab 6

/* 

*/

// Lab 7

/* 

*/