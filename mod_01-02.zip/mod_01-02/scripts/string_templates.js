console.clear();

let someName = 'John';

console.log('Привет, ' + someName + '!'); // старый вариант записи
console.log(`Привет, ${someName}!`); // новый вариант записи с ОБРАТНЫМИ кавычками и форматом записи переменной внутри строк